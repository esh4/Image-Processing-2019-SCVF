class ImageContainer:
    def __init__(self):
        self.img = None

    def set(self, img):
        self.img = img

    def get(self):
        return self.img