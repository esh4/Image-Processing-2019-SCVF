from scvf.io.nt_io import NetworkTableIO
