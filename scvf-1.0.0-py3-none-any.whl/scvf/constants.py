
settings_keys = {
    "pipeline_name" : "pipeline_name",
    "camera_id" : "camera_id",
    "exposure" : "exposure"
}